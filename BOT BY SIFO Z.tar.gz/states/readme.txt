note : please add your appstate in this 
folder. you can put any name just 
make sure the file is ends with .json

warning : do not create the same name
of your existing appstate file, it may
cause error for reading it!

note : you can create multiple appstates,
if encountering error, it's up to your 
operating system.

example : ryukocache.json